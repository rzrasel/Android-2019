package kr.co.timestamping.tsimage;

public class TSImageJni {
    public static native int tsgenImage(String str, String str2, String str3, String str4, int i, String str5, String str6, int i2);

    static {
        System.loadLibrary("tsimage");
    }
}
