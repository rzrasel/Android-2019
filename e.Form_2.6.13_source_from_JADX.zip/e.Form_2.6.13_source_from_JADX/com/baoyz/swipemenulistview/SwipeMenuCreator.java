package com.baoyz.swipemenulistview;

public interface SwipeMenuCreator {
    void create(SwipeMenu swipeMenu, int i);
}
