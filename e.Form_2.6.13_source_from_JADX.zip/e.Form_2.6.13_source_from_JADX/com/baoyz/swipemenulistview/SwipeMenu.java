package com.baoyz.swipemenulistview;

import android.content.Context;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class SwipeMenu {
    private Context mContext;
    private List<SwipeMenuItem> mItems = new ArrayList();
    private List<View> mMenuViewItems = new ArrayList();
    private List<View> mParentViewItems = new ArrayList();
    private int mViewType;

    public SwipeMenu(Context context) {
        this.mContext = context;
    }

    public Context getContext() {
        return this.mContext;
    }

    public void addMenuItem(SwipeMenuItem item) {
        this.mItems.add(item);
    }

    public void removeMenuItem(SwipeMenuItem item) {
        this.mItems.remove(item);
    }

    public void addMenuViewItem(View menuView) {
        this.mMenuViewItems.add(menuView);
    }

    public List<View> getMenuViewItems() {
        return this.mMenuViewItems;
    }

    public View getMenuViewItem(int index) {
        return (View) this.mMenuViewItems.get(index);
    }

    public void addParentViewItem(View menuView) {
        this.mParentViewItems.add(menuView);
    }

    public List<View> getParentViewItems() {
        return this.mParentViewItems;
    }

    public View getParentViewItem(int index) {
        return (View) this.mParentViewItems.get(index);
    }

    public List<SwipeMenuItem> getMenuItems() {
        return this.mItems;
    }

    public SwipeMenuItem getMenuItem(int index) {
        return (SwipeMenuItem) this.mItems.get(index);
    }

    public int getViewType() {
        return this.mViewType;
    }

    public void setViewType(int viewType) {
        this.mViewType = viewType;
    }
}
