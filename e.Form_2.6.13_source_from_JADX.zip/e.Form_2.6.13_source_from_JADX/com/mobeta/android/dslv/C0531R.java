package com.mobeta.android.dslv;

import net.ion.eform.service.R;

public final class C0531R {

    public static final class attr {
        public static final int click_remove_id = 2130772030;
        public static final int collapsed_height = 2130772014;
        public static final int drag_enabled = 2130772024;
        public static final int drag_handle_id = 2130772028;
        public static final int drag_scroll_start = 2130772015;
        public static final int drag_start_mode = 2130772027;
        public static final int drop_animation_duration = 2130772023;
        public static final int fling_handle_id = 2130772029;
        public static final int float_alpha = 2130772020;
        public static final int float_background_color = 2130772017;
        public static final int max_drag_scroll_speed = 2130772016;
        public static final int remove_animation_duration = 2130772022;
        public static final int remove_enabled = 2130772026;
        public static final int remove_mode = 2130772018;
        public static final int slide_shuffle_speed = 2130772021;
        public static final int sort_enabled = 2130772025;
        public static final int track_drag_sort = 2130772019;
        public static final int use_default_controller = 2130772031;
    }

    public static final class id {
        public static final int clickRemove = 2131689507;
        public static final int flingRemove = 2131689508;
        public static final int onDown = 2131689509;
        public static final int onLongPress = 2131689510;
        public static final int onMove = 2131689511;
    }

    public static final class styleable {
        public static final int[] DragSortListView = new int[]{R.attr.collapsed_height, R.attr.drag_scroll_start, R.attr.max_drag_scroll_speed, R.attr.float_background_color, R.attr.remove_mode, R.attr.track_drag_sort, R.attr.float_alpha, R.attr.slide_shuffle_speed, R.attr.remove_animation_duration, R.attr.drop_animation_duration, R.attr.drag_enabled, R.attr.sort_enabled, R.attr.remove_enabled, R.attr.drag_start_mode, R.attr.drag_handle_id, R.attr.fling_handle_id, R.attr.click_remove_id, R.attr.use_default_controller};
        public static final int DragSortListView_click_remove_id = 16;
        public static final int DragSortListView_collapsed_height = 0;
        public static final int DragSortListView_drag_enabled = 10;
        public static final int DragSortListView_drag_handle_id = 14;
        public static final int DragSortListView_drag_scroll_start = 1;
        public static final int DragSortListView_drag_start_mode = 13;
        public static final int DragSortListView_drop_animation_duration = 9;
        public static final int DragSortListView_fling_handle_id = 15;
        public static final int DragSortListView_float_alpha = 6;
        public static final int DragSortListView_float_background_color = 3;
        public static final int DragSortListView_max_drag_scroll_speed = 2;
        public static final int DragSortListView_remove_animation_duration = 8;
        public static final int DragSortListView_remove_enabled = 12;
        public static final int DragSortListView_remove_mode = 4;
        public static final int DragSortListView_slide_shuffle_speed = 7;
        public static final int DragSortListView_sort_enabled = 11;
        public static final int DragSortListView_track_drag_sort = 5;
        public static final int DragSortListView_use_default_controller = 17;
    }
}
