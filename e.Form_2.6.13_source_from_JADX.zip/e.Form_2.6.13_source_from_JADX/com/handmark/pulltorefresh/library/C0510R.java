package com.handmark.pulltorefresh.library;

import net.ion.eform.service.R;

public final class C0510R {

    public static final class anim {
        public static final int slide_in_from_bottom = 2131034139;
        public static final int slide_in_from_top = 2131034140;
        public static final int slide_out_to_bottom = 2131034141;
        public static final int slide_out_to_top = 2131034142;
    }

    public static final class attr {
        public static final int ptrAdapterViewBackground = 2130772066;
        public static final int ptrAnimationStyle = 2130772062;
        public static final int ptrDrawable = 2130772056;
        public static final int ptrDrawableBottom = 2130772068;
        public static final int ptrDrawableEnd = 2130772058;
        public static final int ptrDrawableStart = 2130772057;
        public static final int ptrDrawableTop = 2130772067;
        public static final int ptrHeaderBackground = 2130772051;
        public static final int ptrHeaderSubTextColor = 2130772053;
        public static final int ptrHeaderTextAppearance = 2130772060;
        public static final int ptrHeaderTextColor = 2130772052;
        public static final int ptrListViewExtrasEnabled = 2130772064;
        public static final int ptrMode = 2130772054;
        public static final int ptrOverScroll = 2130772059;
        public static final int ptrRefreshableViewBackground = 2130772050;
        public static final int ptrRotateDrawableWhilePulling = 2130772065;
        public static final int ptrScrollingWhileRefreshingEnabled = 2130772063;
        public static final int ptrShowIndicator = 2130772055;
        public static final int ptrSubHeaderTextAppearance = 2130772061;
        public static final int swipeMenu = 2130772069;
    }

    public static final class dimen {
        public static final int header_footer_left_right_padding = 2131296620;
        public static final int header_footer_top_bottom_padding = 2131296621;
        public static final int indicator_corner_radius = 2131296625;
        public static final int indicator_internal_padding = 2131296626;
        public static final int indicator_right_padding = 2131296627;
    }

    public static final class drawable {
        public static final int default_ptr_flip = 2130837703;
        public static final int default_ptr_rotate = 2130837704;
        public static final int indicator_arrow = 2130837926;
        public static final int indicator_bg_bottom = 2130837927;
        public static final int indicator_bg_top = 2130837928;
    }

    public static final class id {
        public static final int both = 2131689520;
        public static final int disabled = 2131689521;
        public static final int fl_inner = 2131690063;
        public static final int flip = 2131689527;
        public static final int gridview = 2131689476;
        public static final int manualOnly = 2131689522;
        public static final int pullDownFromTop = 2131689523;
        public static final int pullFromEnd = 2131689524;
        public static final int pullFromStart = 2131689525;
        public static final int pullUpFromBottom = 2131689526;
        public static final int pull_to_refresh_image = 2131690064;
        public static final int pull_to_refresh_progress = 2131690065;
        public static final int pull_to_refresh_sub_text = 2131690067;
        public static final int pull_to_refresh_text = 2131690066;
        public static final int rotate = 2131689528;
        public static final int scrollview = 2131689487;
        public static final int webview = 2131689493;
    }

    public static final class layout {
        public static final int pull_to_refresh_header_horizontal = 2130968689;
        public static final int pull_to_refresh_header_vertical = 2130968690;
    }

    public static final class string {
        public static final int pull_to_refresh_from_bottom_pull_label = 2131230736;
        public static final int pull_to_refresh_from_bottom_refreshing_label = 2131230737;
        public static final int pull_to_refresh_from_bottom_release_label = 2131230738;
        public static final int pull_to_refresh_pull_label = 2131230733;
        public static final int pull_to_refresh_refreshing_label = 2131230734;
        public static final int pull_to_refresh_release_label = 2131230735;
    }

    public static final class styleable {
        public static final int[] PullToRefresh = new int[]{R.attr.ptrRefreshableViewBackground, R.attr.ptrHeaderBackground, R.attr.ptrHeaderTextColor, R.attr.ptrHeaderSubTextColor, R.attr.ptrMode, R.attr.ptrShowIndicator, R.attr.ptrDrawable, R.attr.ptrDrawableStart, R.attr.ptrDrawableEnd, R.attr.ptrOverScroll, R.attr.ptrHeaderTextAppearance, R.attr.ptrSubHeaderTextAppearance, R.attr.ptrAnimationStyle, R.attr.ptrScrollingWhileRefreshingEnabled, R.attr.ptrListViewExtrasEnabled, R.attr.ptrRotateDrawableWhilePulling, R.attr.ptrAdapterViewBackground, R.attr.ptrDrawableTop, R.attr.ptrDrawableBottom, R.attr.swipeMenu};
        public static final int PullToRefresh_ptrAdapterViewBackground = 16;
        public static final int PullToRefresh_ptrAnimationStyle = 12;
        public static final int PullToRefresh_ptrDrawable = 6;
        public static final int PullToRefresh_ptrDrawableBottom = 18;
        public static final int PullToRefresh_ptrDrawableEnd = 8;
        public static final int PullToRefresh_ptrDrawableStart = 7;
        public static final int PullToRefresh_ptrDrawableTop = 17;
        public static final int PullToRefresh_ptrHeaderBackground = 1;
        public static final int PullToRefresh_ptrHeaderSubTextColor = 3;
        public static final int PullToRefresh_ptrHeaderTextAppearance = 10;
        public static final int PullToRefresh_ptrHeaderTextColor = 2;
        public static final int PullToRefresh_ptrListViewExtrasEnabled = 14;
        public static final int PullToRefresh_ptrMode = 4;
        public static final int PullToRefresh_ptrOverScroll = 9;
        public static final int PullToRefresh_ptrRefreshableViewBackground = 0;
        public static final int PullToRefresh_ptrRotateDrawableWhilePulling = 15;
        public static final int PullToRefresh_ptrScrollingWhileRefreshingEnabled = 13;
        public static final int PullToRefresh_ptrShowIndicator = 5;
        public static final int PullToRefresh_ptrSubHeaderTextAppearance = 11;
        public static final int PullToRefresh_swipeMenu = 19;
    }
}
