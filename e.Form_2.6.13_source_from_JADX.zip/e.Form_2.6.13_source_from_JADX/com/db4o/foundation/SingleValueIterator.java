package com.db4o.foundation;

public class SingleValueIterator implements Iterator4 {
    private boolean _moved;
    private Object _value;

    public SingleValueIterator(Object value) {
        this._value = value;
    }

    public Object current() {
        if (this._moved && this._value != Iterators.NO_ELEMENT) {
            return this._value;
        }
        throw new IllegalStateException();
    }

    public boolean moveNext() {
        if (this._moved) {
            this._value = Iterators.NO_ELEMENT;
            return false;
        }
        this._moved = true;
        return true;
    }

    public void reset() {
        throw new NotImplementedException();
    }
}
