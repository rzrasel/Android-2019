package com.db4o.foundation;

import com.db4o.DTrace;

public class BlockingQueueStoppedException extends RuntimeException {
    public BlockingQueueStoppedException() {
        if (DTrace.enabled) {
            DTrace.BLOCKING_QUEUE_STOPPED_EXCEPTION.log();
        }
    }
}
