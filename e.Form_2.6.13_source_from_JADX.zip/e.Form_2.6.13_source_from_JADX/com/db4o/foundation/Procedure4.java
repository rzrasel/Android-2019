package com.db4o.foundation;

public interface Procedure4 {
    void apply(Object obj);
}
