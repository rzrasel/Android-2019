package com.db4o.foundation;

import java.lang.reflect.Method;
import java.util.Iterator;

public class ReflectionIterableBase implements IterableBaseWrapper {
    private Object _delegate;
    private Method _method = this._delegate.getClass().getMethod("iterator", new Class[0]);

    public ReflectionIterableBase(Object delegate) throws Exception {
        this._delegate = delegate;
        this._method.setAccessible(true);
    }

    public Iterator iterator() {
        try {
            return (Iterator) this._method.invoke(this._delegate, new Object[0]);
        } catch (Exception exc) {
            exc.printStackTrace();
            return null;
        }
    }

    public Object delegate() {
        return this._delegate;
    }
}
