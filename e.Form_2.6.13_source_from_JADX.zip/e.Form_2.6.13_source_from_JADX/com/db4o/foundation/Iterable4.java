package com.db4o.foundation;

public interface Iterable4 {
    Iterator4 iterator();
}
