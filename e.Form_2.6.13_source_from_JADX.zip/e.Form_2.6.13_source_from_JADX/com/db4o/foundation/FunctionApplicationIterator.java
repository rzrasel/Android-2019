package com.db4o.foundation;

public class FunctionApplicationIterator extends MappingIterator {
    private final Function4 _function;

    public FunctionApplicationIterator(Iterator4 iterator, Function4 function) {
        super(iterator);
        if (function == null) {
            throw new ArgumentNullException();
        }
        this._function = function;
    }

    protected Object map(Object current) {
        return this._function.apply(current);
    }
}
