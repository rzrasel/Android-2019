package com.db4o.foundation;

import java.util.Collection;
import java.util.Iterator;

public class JdkCollectionIterator4 implements Iterator4 {
    private static final Object INVALID = new Object();
    private final Collection _collection;
    private Object _current;
    private Iterator _iterator;

    public JdkCollectionIterator4(Collection collection) {
        this._collection = collection;
        reset();
    }

    public Object current() {
        if (this._current != INVALID) {
            return this._current;
        }
        throw new IllegalStateException();
    }

    public boolean moveNext() {
        if (this._iterator.hasNext()) {
            this._current = this._iterator.next();
            return true;
        }
        this._current = INVALID;
        return false;
    }

    public void reset() {
        this._iterator = this._collection.iterator();
        this._current = INVALID;
    }
}
