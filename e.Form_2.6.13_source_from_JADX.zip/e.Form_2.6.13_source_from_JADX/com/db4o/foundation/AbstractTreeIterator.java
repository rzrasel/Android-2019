package com.db4o.foundation;

public abstract class AbstractTreeIterator implements Iterator4 {
    private Stack4 _stack;
    private final Tree _tree;

    protected abstract Object currentValue(Tree tree);

    public AbstractTreeIterator(Tree tree) {
        this._tree = tree;
    }

    public Object current() {
        if (this._stack == null) {
            throw new IllegalStateException();
        }
        Tree tree = peek();
        if (tree == null) {
            return null;
        }
        return currentValue(tree);
    }

    private Tree peek() {
        return (Tree) this._stack.peek();
    }

    public void reset() {
        this._stack = null;
    }

    public boolean moveNext() {
        if (this._stack == null) {
            initStack();
            if (this._stack != null) {
                return true;
            }
            return false;
        }
        Tree current = peek();
        if (current == null) {
            return false;
        }
        if (pushPreceding(current._subsequent)) {
            return true;
        }
        while (true) {
            this._stack.pop();
            Tree parent = peek();
            if (parent == null) {
                return false;
            }
            if (current == parent._preceding) {
                return true;
            }
            current = parent;
        }
    }

    private void initStack() {
        if (this._tree != null) {
            this._stack = new Stack4();
            pushPreceding(this._tree);
        }
    }

    private boolean pushPreceding(Tree node) {
        if (node == null) {
            return false;
        }
        while (node != null) {
            this._stack.push(node);
            node = node._preceding;
        }
        return true;
    }
}
