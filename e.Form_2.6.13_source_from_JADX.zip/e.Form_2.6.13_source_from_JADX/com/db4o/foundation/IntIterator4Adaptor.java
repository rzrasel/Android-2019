package com.db4o.foundation;

public class IntIterator4Adaptor implements IntIterator4 {
    private final Iterator4 _iterator;

    public IntIterator4Adaptor(Iterator4 iterator) {
        this._iterator = iterator;
    }

    public IntIterator4Adaptor(Iterable4 iterable) {
        this(iterable.iterator());
    }

    public int currentInt() {
        return ((Integer) current()).intValue();
    }

    public Object current() {
        return this._iterator.current();
    }

    public boolean moveNext() {
        return this._iterator.moveNext();
    }

    public void reset() {
        this._iterator.reset();
    }
}
