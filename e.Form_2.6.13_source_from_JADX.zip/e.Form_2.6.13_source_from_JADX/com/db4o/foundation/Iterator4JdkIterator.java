package com.db4o.foundation;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Iterator4JdkIterator implements Iterator {
    private static final Object BEFORE_START = new Object();
    private static final Object BEYOND_END = new Object();
    private Object _current = BEFORE_START;
    private final Iterator4 _delegate;

    public Iterator4JdkIterator(Iterator4 i) {
        this._delegate = i;
    }

    public boolean hasNext() {
        checkBeforeStart();
        return this._current != BEYOND_END;
    }

    public Object next() {
        checkBeforeStart();
        if (this._current == BEYOND_END) {
            throw new NoSuchElementException();
        }
        Object result = this._current;
        if (this._delegate.moveNext()) {
            this._current = this._delegate.current();
        } else {
            this._current = BEYOND_END;
        }
        return result;
    }

    private void checkBeforeStart() {
        if (this._current == BEFORE_START) {
            if (this._delegate.moveNext()) {
                this._current = this._delegate.current();
            } else {
                this._current = BEYOND_END;
            }
        }
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
