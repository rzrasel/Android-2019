package com.db4o.foundation;

public class BlockingQueue implements Queue4 {
    protected Lock4 _lock = new Lock4();
    protected NonblockingQueue _queue = new NonblockingQueue();
    protected boolean _stopped;

    class C02562 implements Closure4 {
        C02562() {
        }

        public Object run() {
            return new Boolean(BlockingQueue.this._queue.hasNext());
        }
    }

    class C02573 implements Closure4 {
        C02573() {
        }

        public Object run() {
            return BlockingQueue.this._queue.iterator();
        }
    }

    class C02584 implements Closure4 {
        C02584() {
        }

        public Object run() {
            if (BlockingQueue.this._queue.hasNext()) {
                return BlockingQueue.this._queue.next();
            }
            if (BlockingQueue.this._stopped) {
                throw new BlockingQueueStoppedException();
            }
            BlockingQueue.this._lock.snooze(2147483647L);
            Object obj = BlockingQueue.this._queue.next();
            if (obj != null) {
                return obj;
            }
            throw new BlockingQueueStoppedException();
        }
    }

    class C02595 implements Closure4 {
        C02595() {
        }

        public Object run() {
            BlockingQueue.this._stopped = true;
            BlockingQueue.this._lock.awake();
            return null;
        }
    }

    public void add(final Object obj) {
        this._lock.run(new Closure4() {
            public Object run() {
                BlockingQueue.this._queue.add(obj);
                BlockingQueue.this._lock.awake();
                return null;
            }
        });
    }

    public boolean hasNext() {
        return ((Boolean) this._lock.run(new C02562())).booleanValue();
    }

    public Iterator4 iterator() {
        return (Iterator4) this._lock.run(new C02573());
    }

    public Object next() throws BlockingQueueStoppedException {
        return this._lock.run(new C02584());
    }

    public void stop() {
        this._lock.run(new C02595());
    }

    public Object nextMatching(final Predicate4 condition) {
        return this._lock.run(new Closure4() {
            public Object run() {
                return BlockingQueue.this._queue.nextMatching(condition);
            }
        });
    }
}
