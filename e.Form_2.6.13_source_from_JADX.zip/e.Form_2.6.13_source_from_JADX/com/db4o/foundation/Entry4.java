package com.db4o.foundation;

public interface Entry4 {
    Object key();

    Object value();
}
