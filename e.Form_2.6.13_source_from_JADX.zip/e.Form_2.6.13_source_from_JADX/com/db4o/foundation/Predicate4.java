package com.db4o.foundation;

public interface Predicate4 {
    boolean match(Object obj);
}
