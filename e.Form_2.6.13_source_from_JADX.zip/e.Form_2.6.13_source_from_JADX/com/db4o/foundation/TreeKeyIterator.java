package com.db4o.foundation;

public class TreeKeyIterator extends AbstractTreeIterator {
    public TreeKeyIterator(Tree tree) {
        super(tree);
    }

    protected Object currentValue(Tree tree) {
        return tree.key();
    }
}
