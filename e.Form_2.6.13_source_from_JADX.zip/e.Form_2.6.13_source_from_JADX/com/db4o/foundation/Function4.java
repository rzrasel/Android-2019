package com.db4o.foundation;

public interface Function4 {
    Object apply(Object obj);
}
