package com.db4o.foundation;

public class Stack4 {
    private List4 _tail;

    public void push(Object obj) {
        this._tail = new List4(this._tail, obj);
    }

    public Object peek() {
        if (this._tail == null) {
            return null;
        }
        return this._tail._element;
    }

    public Object pop() {
        if (this._tail == null) {
            throw new IllegalStateException();
        }
        Object res = this._tail._element;
        this._tail = this._tail._next;
        return res;
    }

    public boolean isEmpty() {
        return this._tail == null;
    }
}
