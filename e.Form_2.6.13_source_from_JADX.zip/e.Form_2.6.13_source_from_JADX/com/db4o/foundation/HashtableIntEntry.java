package com.db4o.foundation;

public class HashtableIntEntry implements Entry4, DeepClone {
    public int _key;
    public HashtableIntEntry _next;
    public Object _object;

    HashtableIntEntry(int a_hash, Object a_object) {
        this._key = a_hash;
        this._object = a_object;
    }

    public Object key() {
        return new Integer(this._key);
    }

    public Object value() {
        return this._object;
    }

    public Object deepClone(Object obj) {
        return deepCloneInternal(new HashtableIntEntry(), obj);
    }

    public boolean sameKeyAs(HashtableIntEntry other) {
        return this._key == other._key;
    }

    protected HashtableIntEntry deepCloneInternal(HashtableIntEntry entry, Object obj) {
        entry._key = this._key;
        entry._next = this._next;
        if (this._object instanceof DeepClone) {
            entry._object = ((DeepClone) this._object).deepClone(obj);
        } else {
            entry._object = this._object;
        }
        if (this._next != null) {
            entry._next = (HashtableIntEntry) this._next.deepClone(obj);
        }
        return entry;
    }

    public String toString() {
        return "" + this._key + ": " + this._object;
    }
}
