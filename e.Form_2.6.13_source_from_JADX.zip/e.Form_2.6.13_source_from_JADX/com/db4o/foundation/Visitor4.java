package com.db4o.foundation;

public interface Visitor4 {
    void visit(Object obj);
}
