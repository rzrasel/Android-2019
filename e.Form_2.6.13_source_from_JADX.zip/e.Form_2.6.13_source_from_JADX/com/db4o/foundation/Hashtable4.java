package com.db4o.foundation;

public class Hashtable4 implements DeepClone, Map4 {
    private static final float FILL = 0.5f;
    public int _mask;
    public int _maximumSize;
    public int _size;
    public HashtableIntEntry[] _table;
    public int _tableSize;

    class C02631 implements Function4 {
        C02631() {
        }

        public Object apply(Object current) {
            return ((Entry4) current).key();
        }
    }

    class C02642 implements Function4 {
        C02642() {
        }

        public Object apply(Object current) {
            return ((Entry4) current).value();
        }
    }

    public Hashtable4(int size) {
        size = newSize(size);
        this._tableSize = 1;
        while (this._tableSize < size) {
            this._tableSize <<= 1;
        }
        this._mask = this._tableSize - 1;
        this._maximumSize = (int) (((float) this._tableSize) * FILL);
        this._table = new HashtableIntEntry[this._tableSize];
    }

    public Hashtable4() {
        this(1);
    }

    protected Hashtable4(DeepClone cloneOnlyCtor) {
    }

    public int size() {
        return this._size;
    }

    public Object deepClone(Object obj) {
        return deepCloneInternal(new Hashtable4((DeepClone) null), obj);
    }

    public void forEachKeyForIdentity(Visitor4 visitor, Object obj) {
        for (HashtableIntEntry entry : this._table) {
            for (HashtableIntEntry entry2 = this._table[i]; entry2 != null; entry2 = entry2._next) {
                if (entry2._object == obj) {
                    visitor.visit(entry2.key());
                }
            }
        }
    }

    public Object get(byte[] key) {
        return getFromObjectEntry(HashtableByteArrayEntry.hash(key), key);
    }

    public Object get(int key) {
        for (HashtableIntEntry entry = this._table[this._mask & key]; entry != null; entry = entry._next) {
            if (entry._key == key) {
                return entry._object;
            }
        }
        return null;
    }

    public Object get(Object key) {
        if (key == null) {
            return null;
        }
        return getFromObjectEntry(key.hashCode(), key);
    }

    public Iterator4 iterator() {
        return new HashtableIterator(this._table);
    }

    public Iterator4 keys() {
        return Iterators.map(iterator(), new C02631());
    }

    public Iterator4 values() {
        return Iterators.map(iterator(), new C02642());
    }

    public boolean containsKey(Object key) {
        if (key == null || getObjectEntry(key.hashCode(), key) == null) {
            return false;
        }
        return true;
    }

    public boolean containsAllKeys(Iterable4 collection) {
        return containsAllKeys(collection.iterator());
    }

    public boolean containsAllKeys(Iterator4 iterator) {
        while (iterator.moveNext()) {
            if (!containsKey(iterator.current())) {
                return false;
            }
        }
        return true;
    }

    public void put(byte[] key, Object value) {
        putEntry(new HashtableByteArrayEntry(key, value));
    }

    public void put(int key, Object value) {
        putEntry(new HashtableIntEntry(key, value));
    }

    public void put(Object key, Object value) {
        if (key == null) {
            throw new ArgumentNullException();
        }
        putEntry(new HashtableObjectEntry(key, value));
    }

    public Object remove(byte[] key) {
        return removeObjectEntry(HashtableByteArrayEntry.hash(key), key);
    }

    public void remove(int key) {
        HashtableIntEntry entry = this._table[this._mask & key];
        HashtableIntEntry predecessor = null;
        while (entry != null) {
            if (entry._key == key) {
                removeEntry(predecessor, entry);
                return;
            } else {
                predecessor = entry;
                entry = entry._next;
            }
        }
    }

    public void remove(Object objectKey) {
        removeObjectEntry(objectKey.hashCode(), objectKey);
    }

    public String toString() {
        return Iterators.join(iterator(), "{", "}", ", ");
    }

    protected Hashtable4 deepCloneInternal(Hashtable4 ret, Object obj) {
        ret._mask = this._mask;
        ret._maximumSize = this._maximumSize;
        ret._size = this._size;
        ret._tableSize = this._tableSize;
        ret._table = new HashtableIntEntry[this._tableSize];
        for (int i = 0; i < this._tableSize; i++) {
            if (this._table[i] != null) {
                ret._table[i] = (HashtableIntEntry) this._table[i].deepClone(obj);
            }
        }
        return ret;
    }

    private int entryIndex(HashtableIntEntry entry) {
        return entry._key & this._mask;
    }

    private HashtableIntEntry findWithSameKey(HashtableIntEntry newEntry) {
        for (HashtableIntEntry existing = this._table[entryIndex(newEntry)]; existing != null; existing = existing._next) {
            if (existing.sameKeyAs(newEntry)) {
                return existing;
            }
        }
        return null;
    }

    private Object getFromObjectEntry(int intKey, Object objectKey) {
        HashtableObjectEntry entry = getObjectEntry(intKey, objectKey);
        return entry == null ? null : entry._object;
    }

    private HashtableObjectEntry getObjectEntry(int intKey, Object objectKey) {
        HashtableObjectEntry entry = (HashtableObjectEntry) this._table[this._mask & intKey];
        while (entry != null) {
            if (entry._key == intKey && entry.hasKey(objectKey)) {
                return entry;
            }
            entry = entry._next;
        }
        return null;
    }

    private void increaseSize() {
        this._tableSize <<= 1;
        this._maximumSize <<= 1;
        this._mask = this._tableSize - 1;
        HashtableIntEntry[] temp = this._table;
        this._table = new HashtableIntEntry[this._tableSize];
        for (HashtableIntEntry reposition : temp) {
            reposition(reposition);
        }
    }

    private void insert(HashtableIntEntry newEntry) {
        this._size++;
        if (this._size > this._maximumSize) {
            increaseSize();
        }
        int index = entryIndex(newEntry);
        newEntry._next = this._table[index];
        this._table[index] = newEntry;
    }

    private final int newSize(int size) {
        return (int) (((float) size) / FILL);
    }

    private void putEntry(HashtableIntEntry newEntry) {
        HashtableIntEntry existing = findWithSameKey(newEntry);
        if (existing != null) {
            replace(existing, newEntry);
        } else {
            insert(newEntry);
        }
    }

    private void removeEntry(HashtableIntEntry predecessor, HashtableIntEntry entry) {
        if (predecessor != null) {
            predecessor._next = entry._next;
        } else {
            this._table[entryIndex(entry)] = entry._next;
        }
        this._size--;
    }

    private Object removeObjectEntry(int intKey, Object objectKey) {
        HashtableObjectEntry entry = this._table[this._mask & intKey];
        HashtableObjectEntry predecessor = null;
        while (entry != null) {
            if (entry._key == intKey && entry.hasKey(objectKey)) {
                removeEntry(predecessor, entry);
                return entry._object;
            }
            predecessor = entry;
            entry = entry._next;
        }
        return null;
    }

    private void replace(HashtableIntEntry existing, HashtableIntEntry newEntry) {
        newEntry._next = existing._next;
        HashtableIntEntry entry = this._table[entryIndex(existing)];
        if (entry == existing) {
            this._table[entryIndex(existing)] = newEntry;
            return;
        }
        while (entry._next != existing) {
            entry = entry._next;
        }
        entry._next = newEntry;
    }

    private void reposition(HashtableIntEntry entry) {
        if (entry != null) {
            reposition(entry._next);
            entry._next = this._table[entryIndex(entry)];
            this._table[entryIndex(entry)] = entry;
        }
    }
}
