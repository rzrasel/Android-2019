package com.db4o.foundation;

public interface DeepClone {
    Object deepClone(Object obj);
}
