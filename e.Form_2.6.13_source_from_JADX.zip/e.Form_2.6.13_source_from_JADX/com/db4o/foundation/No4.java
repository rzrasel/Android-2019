package com.db4o.foundation;

public class No4 {
    public static final No4 INSTANCE = new No4();
}
