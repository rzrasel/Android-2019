package com.db4o.foundation;

public interface QuickSortable4 {
    int compare(int i, int i2);

    int size();

    void swap(int i, int i2);
}
