package com.db4o.foundation;

public final class IntByRef {
    public int value;

    public IntByRef(int initialValue) {
        this.value = initialValue;
    }
}
