package com.db4o.foundation;

public final class SimpleTimer implements Runnable {
    private final int _interval;
    private Lock4 _lock;
    private final String _name;
    private final Runnable _runnable;
    public volatile boolean stopped = false;

    public SimpleTimer(Runnable runnable, int interval, String name) {
        this._runnable = runnable;
        this._interval = interval;
        this._name = name;
        this._lock = new Lock4();
    }

    public void start() {
        Thread thread = new Thread(this);
        thread.setDaemon(true);
        thread.setName(this._name);
        thread.start();
    }

    public void stop() {
        this.stopped = true;
        synchronized (this._lock) {
            this._lock.awake();
        }
    }

    public void run() {
        while (!this.stopped) {
            synchronized (this._lock) {
                this._lock.snooze((long) this._interval);
            }
            if (!this.stopped) {
                this._runnable.run();
            }
        }
    }
}
