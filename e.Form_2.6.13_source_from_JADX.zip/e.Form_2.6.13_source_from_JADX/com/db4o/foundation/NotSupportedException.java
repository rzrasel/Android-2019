package com.db4o.foundation;

public class NotSupportedException extends RuntimeException {
    public NotSupportedException(String msg) {
        super(msg);
    }
}
