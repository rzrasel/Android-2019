package com.db4o.foundation;

public class HashtableObjectEntry extends HashtableIntEntry {
    public Object _objectKey;

    HashtableObjectEntry(int a_hash, Object a_key, Object a_object) {
        super(a_hash, a_object);
        this._objectKey = a_key;
    }

    HashtableObjectEntry(Object a_key, Object a_object) {
        super(a_key.hashCode(), a_object);
        this._objectKey = a_key;
    }

    public Object key() {
        return this._objectKey;
    }

    public Object deepClone(Object obj) {
        return deepCloneInternal(new HashtableObjectEntry(), obj);
    }

    protected HashtableIntEntry deepCloneInternal(HashtableIntEntry entry, Object obj) {
        ((HashtableObjectEntry) entry)._objectKey = this._objectKey;
        return super.deepCloneInternal(entry, obj);
    }

    public boolean hasKey(Object key) {
        return this._objectKey.equals(key);
    }

    public boolean sameKeyAs(HashtableIntEntry other) {
        return other instanceof HashtableObjectEntry ? hasKey(((HashtableObjectEntry) other)._objectKey) : false;
    }

    public String toString() {
        return "" + this._objectKey + ": " + this._object;
    }
}
