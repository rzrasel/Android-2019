package com.db4o.foundation;

public class TimeStampIdGenerator {
    private long _last;

    public static long idToMilliseconds(long id) {
        return id >> 15;
    }

    public TimeStampIdGenerator() {
        this(0);
    }

    public TimeStampIdGenerator(long minimumNext) {
        this._last = minimumNext;
    }

    public long generate() {
        long t = System.currentTimeMillis() << 15;
        if (t <= this._last) {
            this._last++;
        } else {
            this._last = t;
        }
        return this._last;
    }

    public long last() {
        return this._last;
    }

    public boolean setMinimumNext(long newMinimum) {
        if (newMinimum <= this._last) {
            return false;
        }
        this._last = newMinimum;
        return true;
    }
}
