package com.db4o.foundation;

import java.util.Collection;
import java.util.Iterator;

public class CollectionIterableBase implements IterableBaseWrapper {
    private Collection _delegate;

    public CollectionIterableBase(Collection delegate) {
        this._delegate = delegate;
    }

    public Iterator iterator() {
        return this._delegate.iterator();
    }

    public Object delegate() {
        return this._delegate;
    }
}
