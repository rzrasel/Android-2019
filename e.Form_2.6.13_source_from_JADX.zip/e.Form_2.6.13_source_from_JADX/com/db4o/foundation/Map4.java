package com.db4o.foundation;

public interface Map4 {
    Object get(Object obj);

    void put(Object obj, Object obj2);
}
