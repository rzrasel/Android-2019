package com.db4o.foundation;

import java.util.Iterator;

public interface IterableBase {
    Iterator iterator();
}
