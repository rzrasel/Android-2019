package com.db4o.foundation;

public class Cool {
    public static void sleepIgnoringInterruption(long millis) {
        try {
            Thread.sleep(millis);
        } catch (Exception e) {
        }
    }

    public static void loopWithTimeout(long millisecondsTimeout, ConditionalBlock block) {
        StopWatch watch = new AutoStopWatch();
        while (block.run()) {
            if (watch.peek() >= millisecondsTimeout) {
                return;
            }
        }
    }
}
