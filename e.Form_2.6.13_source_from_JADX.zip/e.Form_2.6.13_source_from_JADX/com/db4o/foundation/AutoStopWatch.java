package com.db4o.foundation;

public class AutoStopWatch extends StopWatch {
    public AutoStopWatch() {
        start();
    }
}
