package com.db4o.foundation;

public class Iterators {
    public static final Iterable4 EMPTY_ITERABLE = new C02662();
    public static final Iterator4 EMPTY_ITERATOR = new C02651();
    static final Object NO_ELEMENT = new Object();
    public static final Object SKIP = new Object();

    static class C02651 implements Iterator4 {
        C02651() {
        }

        public Object current() {
            throw new IllegalStateException();
        }

        public boolean moveNext() {
            return false;
        }

        public void reset() {
            throw new NotImplementedException();
        }
    }

    static class C02662 implements Iterable4 {
        C02662() {
        }

        public Iterator4 iterator() {
            return Iterators.EMPTY_ITERATOR;
        }
    }

    static class C02695 implements ArrayFactory {
        C02695() {
        }

        public Object[] newArray(int size) {
            return new Object[size];
        }
    }

    static class C02717 implements ArrayFactory {
        C02717() {
        }

        public Object[] newArray(int size) {
            return new Iterable4[size];
        }
    }

    public static Iterable4 enumerate(final Iterable4 iterable) {
        return new Iterable4() {
            public Iterator4 iterator() {
                return new EnumerateIterator(iterable.iterator());
            }
        };
    }

    public static Iterator4 concat(Iterator4[] array) {
        return concat(iterate(array));
    }

    public static Iterator4 concat(Iterator4 iterators) {
        return new CompositeIterator4(iterators);
    }

    public static Iterable4 concat(Iterable4[] iterables) {
        return concat(iterable((Object[]) iterables));
    }

    public static Iterable4 concat(Iterable4 iterables) {
        return new CompositeIterable4(iterables);
    }

    public static Iterator4 concat(Iterator4 first, Iterator4 second) {
        return concat(new Iterator4[]{first, second});
    }

    public static Iterable4 concatMap(Iterable4 iterable, Function4 function) {
        return concat(map(iterable, function));
    }

    public static Iterator4 map(Iterator4 iterator, Function4 function) {
        return new FunctionApplicationIterator(iterator, function);
    }

    public static Iterator4 map(Object[] array, Function4 function) {
        return map(new ArrayIterator4(array), function);
    }

    public static Iterator4 filter(Object[] array, Predicate4 predicate) {
        return filter(new ArrayIterator4(array), predicate);
    }

    public static Iterator4 filter(Iterator4 iterator, Predicate4 predicate) {
        return new FilteredIterator(iterator, predicate);
    }

    public static Iterable4 cons(final Object element) {
        return new Iterable4() {
            public Iterator4 iterator() {
                return Iterators.iterateSingle(element);
            }
        };
    }

    public static Iterable4 cons(Iterable4 front, Object last) {
        return concat(iterable(new Object[]{front, cons(last)}));
    }

    public static Iterator4 iterate(Object[] array) {
        return new ArrayIterator4(array);
    }

    public static int size(Iterable4 iterable) {
        return size(iterable.iterator());
    }

    public static Object next(Iterator4 iterator) {
        if (iterator.moveNext()) {
            return iterator.current();
        }
        throw new IllegalStateException();
    }

    public static int size(Iterator4 iterator) {
        int count = 0;
        while (iterator.moveNext()) {
            count++;
        }
        return count;
    }

    public static String toString(Iterable4 i) {
        return toString(i.iterator());
    }

    public static String toString(Iterator4 i) {
        return join(i, "[", "]", ", ");
    }

    public static String join(Iterator4 i, String separator) {
        return join(i, "", "", separator);
    }

    public static String join(Iterator4 i, String prefix, String suffix, String separator) {
        StringBuffer sb = new StringBuffer();
        sb.append(prefix);
        if (i.moveNext()) {
            sb.append(i.current());
            while (i.moveNext()) {
                sb.append(separator);
                sb.append(i.current());
            }
        }
        sb.append(suffix);
        return sb.toString();
    }

    public static Object[] toArray(Iterator4 tests) {
        return toArray(tests, new C02695());
    }

    public static Object[] toArray(Iterator4 tests, ArrayFactory factory) {
        Collection4 elements = new Collection4(tests);
        return elements.toArray(factory.newArray(elements.size()));
    }

    public static Iterator4 flatten(Iterator4 iterator) {
        return new FlatteningIterator(iterator);
    }

    public static Iterable4 map(final Iterable4 iterable, final Function4 function) {
        return new Iterable4() {
            public Iterator4 iterator() {
                return Iterators.map(iterable.iterator(), function);
            }
        };
    }

    public static Iterable4 crossProduct(Iterable4 iterables) {
        return crossProduct((Iterable4[]) toArray(iterables.iterator(), new C02717()));
    }

    public static Iterable4 crossProduct(Iterable4[] iterables) {
        return crossProduct(iterables, 0, EMPTY_ITERABLE);
    }

    private static Iterable4 crossProduct(final Iterable4[] iterables, final int level, final Iterable4 row) {
        if (level == iterables.length - 1) {
            return map(iterables[level], new Function4() {
                public Object apply(Object arg) {
                    return Iterators.cons(row, arg);
                }
            });
        }
        return concatMap(iterables[level], new Function4() {
            public Object apply(Object arg) {
                return Iterators.crossProduct(iterables, level + 1, Iterators.cons(row, arg));
            }
        });
    }

    public static Iterable4 iterable(final Object[] objects) {
        return new Iterable4() {
            public Iterator4 iterator() {
                return Iterators.iterate(objects);
            }
        };
    }

    public static Iterator4 iterateSingle(Object element) {
        return new SingleValueIterator(element);
    }

    public static Iterable4 iterable(final Iterator4 iterator) {
        return new Iterable4() {
            public Iterator4 iterator() {
                return iterator;
            }
        };
    }
}
