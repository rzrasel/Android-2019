package com.db4o.foundation;

public class Collection4Iterator extends Iterator4Impl {
    private final Collection4 _collection;
    private final int _initialVersion = currentVersion();

    public Collection4Iterator(Collection4 collection, List4 first) {
        super(first);
        this._collection = collection;
    }

    public boolean moveNext() {
        validate();
        return super.moveNext();
    }

    public Object current() {
        validate();
        return super.current();
    }

    private void validate() {
        if (this._initialVersion != currentVersion()) {
            throw new InvalidIteratorException();
        }
    }

    private int currentVersion() {
        return this._collection.version();
    }
}
