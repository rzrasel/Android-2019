package com.db4o.foundation;

public class NoDuplicatesQueue implements Queue4 {
    private Queue4 _queue;
    private Hashtable4 _seen = new Hashtable4();

    public NoDuplicatesQueue(Queue4 queue) {
        this._queue = queue;
    }

    public void add(Object obj) {
        if (!this._seen.containsKey(obj)) {
            this._queue.add(obj);
            this._seen.put(obj, obj);
        }
    }

    public boolean hasNext() {
        return this._queue.hasNext();
    }

    public Iterator4 iterator() {
        return this._queue.iterator();
    }

    public Object next() {
        return this._queue.next();
    }

    public Object nextMatching(Predicate4 condition) {
        return this._queue.nextMatching(condition);
    }
}
