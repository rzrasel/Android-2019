package com.db4o.foundation;

public interface IntObjectVisitor {
    void visit(int i, Object obj);
}
