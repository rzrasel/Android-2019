package com.db4o.foundation;

public class StopWatch {
    private long _elapsed;
    private long _started;

    public void start() {
        this._started = System.currentTimeMillis();
    }

    public void stop() {
        this._elapsed = peek();
    }

    public long peek() {
        return System.currentTimeMillis() - this._started;
    }

    public long elapsed() {
        return this._elapsed;
    }
}
