package com.db4o.foundation;

public class Lock4 {
    public Object run(Closure4 closure) {
        Object run;
        synchronized (this) {
            run = closure.run();
        }
        return run;
    }

    public void snooze(long timeout) {
        try {
            wait(timeout);
        } catch (Exception e) {
        }
    }

    public void awake() {
        notify();
    }
}
