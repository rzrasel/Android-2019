package com.db4o.foundation;

public interface IntIterator4 extends Iterator4 {
    int currentInt();
}
