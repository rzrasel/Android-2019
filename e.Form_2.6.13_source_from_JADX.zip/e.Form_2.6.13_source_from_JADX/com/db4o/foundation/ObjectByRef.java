package com.db4o.foundation;

public final class ObjectByRef {
    public Object value;

    public ObjectByRef(Object value_) {
        this.value = value_;
    }
}
