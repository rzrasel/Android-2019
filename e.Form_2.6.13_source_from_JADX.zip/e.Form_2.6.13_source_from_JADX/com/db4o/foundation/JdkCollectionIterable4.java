package com.db4o.foundation;

import java.util.Collection;

public class JdkCollectionIterable4 implements Iterable4 {
    private final Collection _collection;

    public JdkCollectionIterable4(Collection collection) {
        this._collection = collection;
    }

    public Iterator4 iterator() {
        return new JdkCollectionIterator4(this._collection);
    }
}
