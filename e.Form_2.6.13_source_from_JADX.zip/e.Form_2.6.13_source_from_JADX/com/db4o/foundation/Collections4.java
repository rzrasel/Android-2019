package com.db4o.foundation;

public class Collections4 {

    private static class UnmodifiableSequence4 implements Sequence4 {
        private Sequence4 _sequence;

        public UnmodifiableSequence4(Sequence4 sequence) {
            this._sequence = sequence;
        }

        public void add(Object element) {
            throw new IllegalStateException();
        }

        public boolean isEmpty() {
            return this._sequence.isEmpty();
        }

        public Iterator4 iterator() {
            return this._sequence.iterator();
        }

        public Object get(int index) {
            return this._sequence.get(index);
        }
    }

    public static Sequence4 unmodifiableList(Sequence4 orig) {
        return new UnmodifiableSequence4(orig);
    }
}
