package com.db4o.foundation;

public class NotImplementedException extends RuntimeException {
    public NotImplementedException(String msg) {
        super(msg);
    }
}
