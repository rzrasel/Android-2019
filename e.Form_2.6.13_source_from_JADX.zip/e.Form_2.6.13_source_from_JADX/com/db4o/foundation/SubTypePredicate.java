package com.db4o.foundation;

public class SubTypePredicate implements Predicate4 {
    private final Class _class;

    public SubTypePredicate(Class clazz) {
        this._class = clazz;
    }

    public boolean match(Object candidate) {
        return this._class.isInstance(candidate);
    }
}
