package com.db4o.foundation;

public class Coercion4 {
    public static Object toSByte(Object obj) {
        if (obj instanceof Byte) {
            return obj;
        }
        if (obj instanceof Number) {
            Number number = (Number) obj;
            if (((double) number.byteValue()) == number.doubleValue()) {
                return new Byte(number.byteValue());
            }
        }
        return No4.INSTANCE;
    }

    public static Object toShort(Object obj) {
        if (obj instanceof Short) {
            return obj;
        }
        if (obj instanceof Number) {
            Number number = (Number) obj;
            if (((double) number.shortValue()) == number.doubleValue()) {
                return new Short(number.shortValue());
            }
        }
        return No4.INSTANCE;
    }

    public static Object toInt(Object obj) {
        if (obj instanceof Integer) {
            return obj;
        }
        if (obj instanceof Number) {
            Number number = (Number) obj;
            if (((double) number.intValue()) == number.doubleValue()) {
                return new Integer(number.intValue());
            }
        }
        return No4.INSTANCE;
    }

    public static Object toLong(Object obj) {
        if (obj instanceof Long) {
            return obj;
        }
        if (obj instanceof Number) {
            Number number = (Number) obj;
            if (((double) number.longValue()) == number.doubleValue()) {
                return new Long(number.longValue());
            }
        }
        return No4.INSTANCE;
    }

    public static Object toFloat(Object obj) {
        if (obj instanceof Float) {
            return obj;
        }
        if (obj instanceof Number) {
            Number number = (Number) obj;
            if (((double) number.floatValue()) == number.doubleValue()) {
                return new Float(number.floatValue());
            }
        }
        return No4.INSTANCE;
    }

    public static Object toDouble(Object obj) {
        if (obj instanceof Double) {
            return obj;
        }
        if (obj instanceof Number) {
            return new Double(((Number) obj).doubleValue());
        }
        return No4.INSTANCE;
    }
}
