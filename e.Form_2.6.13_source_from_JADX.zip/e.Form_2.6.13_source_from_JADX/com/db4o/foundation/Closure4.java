package com.db4o.foundation;

public interface Closure4 {
    Object run();
}
