package com.db4o.foundation;

public class HashtableIterator implements Iterator4 {
    private HashtableIntEntry _currentEntry;
    private int _currentIndex;
    private final HashtableIntEntry[] _table;

    public HashtableIterator(HashtableIntEntry[] table) {
        this._table = table;
        reset();
    }

    private void checkInvalidTable() {
        if (this._table == null || this._table.length == 0) {
            positionBeyondLast();
        }
    }

    public Object current() {
        if (this._currentEntry != null) {
            return this._currentEntry;
        }
        throw new IllegalStateException();
    }

    public boolean moveNext() {
        if (isBeyondLast()) {
            return false;
        }
        if (this._currentEntry != null) {
            this._currentEntry = this._currentEntry._next;
        }
        while (this._currentEntry == null) {
            if (this._currentIndex >= this._table.length) {
                positionBeyondLast();
                return false;
            }
            HashtableIntEntry[] hashtableIntEntryArr = this._table;
            int i = this._currentIndex;
            this._currentIndex = i + 1;
            this._currentEntry = hashtableIntEntryArr[i];
        }
        return true;
    }

    public void reset() {
        this._currentEntry = null;
        this._currentIndex = 0;
        checkInvalidTable();
    }

    private boolean isBeyondLast() {
        return this._currentIndex == -1;
    }

    private void positionBeyondLast() {
        this._currentIndex = -1;
    }
}
