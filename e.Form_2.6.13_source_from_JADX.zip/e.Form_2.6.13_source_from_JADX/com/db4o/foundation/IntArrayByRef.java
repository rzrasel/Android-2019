package com.db4o.foundation;

public class IntArrayByRef {
    public int[] value;

    public IntArrayByRef(int[] initialValue) {
        this.value = initialValue;
    }
}
