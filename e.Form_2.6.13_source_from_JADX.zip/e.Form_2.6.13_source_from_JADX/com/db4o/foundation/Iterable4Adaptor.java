package com.db4o.foundation;

public class Iterable4Adaptor {
    private static final Object EOF_MARKER = new Object();
    private static final Object MOVE_NEXT_MARKER = new Object();
    private Object _current = MOVE_NEXT_MARKER;
    private final Iterable4 _delegate;
    private Iterator4 _iterator;

    public Iterable4Adaptor(Iterable4 delegate_) {
        this._delegate = delegate_;
    }

    public boolean hasNext() {
        if (this._current == MOVE_NEXT_MARKER) {
            return moveNext();
        }
        return this._current != EOF_MARKER;
    }

    public Object next() {
        if (hasNext()) {
            Object returnValue = this._current;
            this._current = MOVE_NEXT_MARKER;
            return returnValue;
        }
        throw new IllegalStateException();
    }

    protected boolean moveNext() {
        if (this._iterator == null) {
            this._iterator = this._delegate.iterator();
        }
        if (this._iterator.moveNext()) {
            this._current = this._iterator.current();
            return true;
        }
        this._current = EOF_MARKER;
        return false;
    }

    public void reset() {
        this._iterator = null;
        this._current = MOVE_NEXT_MARKER;
    }
}
