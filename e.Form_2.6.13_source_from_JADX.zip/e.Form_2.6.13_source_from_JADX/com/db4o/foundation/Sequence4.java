package com.db4o.foundation;

public interface Sequence4 extends Iterable4 {
    void add(Object obj);

    Object get(int i);

    boolean isEmpty();
}
