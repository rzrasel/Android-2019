package com.db4o.foundation;

public class IntIterator4Impl implements IntIterator4 {
    private int[] _content;
    private final int _count;
    private int _current;

    public IntIterator4Impl(int[] content, int count) {
        this._content = content;
        this._count = count;
        reset();
    }

    public int currentInt() {
        if (this._content != null && this._current != this._count) {
            return this._content[this._current];
        }
        throw new IllegalStateException();
    }

    public Object current() {
        return new Integer(currentInt());
    }

    public boolean moveNext() {
        if (this._current < this._count - 1) {
            this._current++;
            return true;
        }
        this._content = null;
        return false;
    }

    public void reset() {
        this._current = -1;
    }
}
