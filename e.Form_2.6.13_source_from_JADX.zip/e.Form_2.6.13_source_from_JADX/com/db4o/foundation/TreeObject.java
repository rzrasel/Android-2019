package com.db4o.foundation;

public class TreeObject extends Tree {
    private final Comparison4 _function;
    private final Object _object;

    public TreeObject(Object object, Comparison4 function) {
        this._object = object;
        this._function = function;
    }

    public int compare(Tree tree) {
        return this._function.compare(this._object, tree.key());
    }

    public Object key() {
        return this._object;
    }
}
