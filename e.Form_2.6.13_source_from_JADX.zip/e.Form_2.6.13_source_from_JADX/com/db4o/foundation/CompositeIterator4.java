package com.db4o.foundation;

public class CompositeIterator4 implements Iterator4 {
    protected Iterator4 _currentIterator;
    protected final Iterator4 _iterators;

    public CompositeIterator4(Iterator4[] iterators) {
        this(new ArrayIterator4(iterators));
    }

    public CompositeIterator4(Iterator4 iterators) {
        if (iterators == null) {
            throw new ArgumentNullException();
        }
        this._iterators = iterators;
    }

    public boolean moveNext() {
        if (this._currentIterator == null) {
            if (!this._iterators.moveNext()) {
                return false;
            }
            this._currentIterator = nextIterator(this._iterators.current());
        }
        if (this._currentIterator.moveNext()) {
            return true;
        }
        this._currentIterator = null;
        return moveNext();
    }

    public void reset() {
        resetIterators();
        this._currentIterator = null;
        this._iterators.reset();
    }

    private void resetIterators() {
        this._iterators.reset();
        while (this._iterators.moveNext()) {
            nextIterator(this._iterators.current()).reset();
        }
    }

    public Iterator4 currentIterator() {
        return this._currentIterator;
    }

    public Object current() {
        return this._currentIterator.current();
    }

    protected Iterator4 nextIterator(Object current) {
        return (Iterator4) current;
    }
}
