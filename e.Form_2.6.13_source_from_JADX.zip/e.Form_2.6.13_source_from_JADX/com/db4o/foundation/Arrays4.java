package com.db4o.foundation;

public class Arrays4 {
    public static int indexOf(Object[] array, Object element) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == element) {
                return i;
            }
        }
        return -1;
    }

    public static boolean areEqual(byte[] x, byte[] y) {
        if (x == y) {
            return true;
        }
        if (x == null) {
            return false;
        }
        if (x.length != y.length) {
            return false;
        }
        for (int i = 0; i < x.length; i++) {
            if (y[i] != x[i]) {
                return false;
            }
        }
        return true;
    }

    public static boolean containsInstanceOf(Object[] array, Class klass) {
        if (array == null) {
            return false;
        }
        for (Object isInstance : array) {
            if (klass.isInstance(isInstance)) {
                return true;
            }
        }
        return false;
    }
}
