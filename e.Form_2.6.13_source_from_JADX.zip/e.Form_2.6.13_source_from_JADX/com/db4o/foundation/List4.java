package com.db4o.foundation;

import com.db4o.types.Unversioned;

public final class List4 implements Unversioned {
    public Object _element;
    public List4 _next;

    public List4(Object element) {
        this._element = element;
    }

    public List4(List4 next, Object element) {
        this._next = next;
        this._element = element;
    }

    boolean holds(Object obj) {
        if (obj == null) {
            return this._element == null;
        } else {
            return obj.equals(this._element);
        }
    }
}
