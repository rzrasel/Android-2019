package com.db4o.foundation;

public class TreeNodeIterator extends AbstractTreeIterator {
    public TreeNodeIterator(Tree tree) {
        super(tree);
    }

    protected Object currentValue(Tree tree) {
        return tree.root();
    }
}
