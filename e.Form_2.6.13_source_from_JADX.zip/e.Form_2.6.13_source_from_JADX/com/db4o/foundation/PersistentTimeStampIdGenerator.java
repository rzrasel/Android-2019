package com.db4o.foundation;

public class PersistentTimeStampIdGenerator {
    private boolean _dirty;
    private final TimeStampIdGenerator _generator = new TimeStampIdGenerator();

    public long next() {
        this._dirty = true;
        return this._generator.generate();
    }

    public void setMinimumNext(long val) {
        if (this._generator.setMinimumNext(val)) {
            this._dirty = true;
        }
    }

    public long lastTimeStampId() {
        return this._generator.last();
    }

    public boolean isDirty() {
        return this._dirty;
    }

    public void setClean() {
        this._dirty = false;
    }
}
