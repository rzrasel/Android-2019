package com.db4o.foundation;

public final class PrimitiveCodec {
    public static final int INT_LENGTH = 4;
    public static final int LONG_LENGTH = 8;

    public static final int readInt(byte[] buffer, int offset) {
        offset += 3;
        offset--;
        offset--;
        return (((buffer[offset] & 255) | ((buffer[offset] & 255) << 8)) | ((buffer[offset] & 255) << 16)) | (buffer[offset - 1] << 24);
    }

    public static final void writeInt(byte[] buffer, int offset, int val) {
        offset += 3;
        buffer[offset] = (byte) val;
        offset--;
        val >>= 8;
        buffer[offset] = (byte) val;
        offset--;
        val >>= 8;
        buffer[offset] = (byte) val;
        buffer[offset - 1] = (byte) (val >> 8);
    }

    public static final void writeLong(byte[] buffer, long val) {
        writeLong(buffer, 0, val);
    }

    public static final void writeLong(byte[] buffer, int offset, long val) {
        int i = 0;
        int offset2 = offset;
        while (i < 8) {
            offset = offset2 + 1;
            buffer[offset2] = (byte) ((int) (val >> ((7 - i) * 8)));
            i++;
            offset2 = offset;
        }
    }

    public static final long readLong(byte[] buffer, int offset) {
        long ret = 0;
        int i = 0;
        int offset2 = offset;
        while (i < 8) {
            ret = (ret << 8) + ((long) (buffer[offset2] & 255));
            i++;
            offset2++;
        }
        return ret;
    }
}
