package com.db4o.foundation;

public class KeySpec {
    private final Object _defaultValue;

    public KeySpec(byte defaultValue) {
        this._defaultValue = new Byte(defaultValue);
    }

    public KeySpec(int defaultValue) {
        this._defaultValue = new Integer(defaultValue);
    }

    public KeySpec(boolean defaultValue) {
        this._defaultValue = new Boolean(defaultValue);
    }

    public KeySpec(Object defaultValue) {
        this._defaultValue = defaultValue;
    }

    public Object defaultValue() {
        return this._defaultValue;
    }
}
