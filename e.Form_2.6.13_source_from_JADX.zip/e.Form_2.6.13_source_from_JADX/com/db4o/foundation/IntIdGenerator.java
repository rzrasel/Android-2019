package com.db4o.foundation;

public class IntIdGenerator {
    private int _current = 1;

    public int next() {
        this._current++;
        if (this._current < 0) {
            this._current = 1;
        }
        return this._current;
    }
}
