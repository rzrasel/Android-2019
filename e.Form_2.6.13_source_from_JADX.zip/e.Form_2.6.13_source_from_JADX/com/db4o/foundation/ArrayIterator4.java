package com.db4o.foundation;

public class ArrayIterator4 extends IndexedIterator {
    private final Object[] _elements;

    public ArrayIterator4(Object[] elements) {
        super(elements.length);
        this._elements = elements;
    }

    protected Object get(int index) {
        return this._elements[index];
    }
}
