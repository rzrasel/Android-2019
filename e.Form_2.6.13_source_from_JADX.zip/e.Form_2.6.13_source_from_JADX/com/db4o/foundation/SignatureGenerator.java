package com.db4o.foundation;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

public class SignatureGenerator {
    private static int _counter;
    private static final Random _random = new Random();

    public static String generateSignature() {
        StringBuffer sb = new StringBuffer();
        try {
            sb.append(InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
        }
        int hostAddress = 0;
        try {
            for (byte b : InetAddress.getLocalHost().getAddress()) {
                hostAddress = (hostAddress << 4) - b;
            }
        } catch (UnknownHostException e2) {
        }
        sb.append(Integer.toHexString(hostAddress));
        sb.append(Long.toHexString(System.currentTimeMillis()));
        sb.append(pad(Integer.toHexString(randomInt())));
        int i = _counter;
        _counter = i + 1;
        sb.append(Integer.toHexString(i));
        return sb.toString();
    }

    private static int randomInt() {
        return _random.nextInt();
    }

    private static String pad(String str) {
        return (str + "XXXXXXXX").substring(0, 8);
    }
}
