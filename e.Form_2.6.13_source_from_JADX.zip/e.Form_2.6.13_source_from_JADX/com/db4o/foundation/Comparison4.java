package com.db4o.foundation;

public interface Comparison4 {
    int compare(Object obj, Object obj2);
}
