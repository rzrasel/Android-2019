package com.db4o.foundation;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

public class StackTracer {

    static class TracingOutputStream extends OutputStream {
        private static final int IGNORE_FIRST_BYTES = 3;
        private static final int IGNORE_FIRST_WRITE_CALLS = 2;
        private final StringBuffer _stringBuffer = new StringBuffer();
        private int _writeCalls;

        TracingOutputStream() {
        }

        public void write(byte[] b, int off, int len) throws IOException {
            int i = this._writeCalls;
            this._writeCalls = i + 1;
            if (i >= 2) {
                for (int i2 = off + 3; i2 < off + len; i2++) {
                    this._stringBuffer.append((char) b[i2]);
                }
            }
        }

        public void write(int b) throws IOException {
            throw new IllegalStateException();
        }

        String stackTrace() {
            return this._stringBuffer.toString();
        }
    }

    public static String stackTrace() {
        try {
            throw new Exception();
        } catch (Exception ex) {
            TracingOutputStream tos = new TracingOutputStream();
            ex.printStackTrace(new PrintWriter(tos, true));
            return tos.stackTrace();
        }
    }
}
