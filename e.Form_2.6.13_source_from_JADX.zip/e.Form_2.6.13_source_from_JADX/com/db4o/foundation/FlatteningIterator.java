package com.db4o.foundation;

public class FlatteningIterator extends CompositeIterator4 {
    private IteratorStack _stack;

    private static class IteratorStack {
        public final Iterator4 iterator;
        public final IteratorStack next;

        public IteratorStack(Iterator4 iterator_, IteratorStack next_) {
            this.iterator = iterator_;
            this.next = next_;
        }
    }

    public FlatteningIterator(Iterator4 iterators) {
        super(iterators);
    }

    public boolean moveNext() {
        if (this._currentIterator == null) {
            if (this._stack == null) {
                this._currentIterator = this._iterators;
            } else {
                this._currentIterator = pop();
            }
        }
        if (this._currentIterator.moveNext()) {
            Object current = this._currentIterator.current();
            if (!(current instanceof Iterator4)) {
                return true;
            }
            push(this._currentIterator);
            this._currentIterator = nextIterator(current);
            return moveNext();
        } else if (this._currentIterator == this._iterators) {
            return false;
        } else {
            this._currentIterator = null;
            return moveNext();
        }
    }

    private void push(Iterator4 currentIterator) {
        this._stack = new IteratorStack(currentIterator, this._stack);
    }

    private Iterator4 pop() {
        Iterator4 iterator = this._stack.iterator;
        this._stack = this._stack.next;
        return iterator;
    }
}
