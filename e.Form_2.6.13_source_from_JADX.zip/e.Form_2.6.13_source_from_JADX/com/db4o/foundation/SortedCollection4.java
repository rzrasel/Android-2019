package com.db4o.foundation;

public class SortedCollection4 {
    private final Comparison4 _comparison;
    private Tree _tree;

    public SortedCollection4(Comparison4 comparison) {
        if (comparison == null) {
            throw new ArgumentNullException();
        }
        this._comparison = comparison;
        this._tree = null;
    }

    public Object singleElement() {
        if (1 == size()) {
            return this._tree.key();
        }
        throw new IllegalStateException();
    }

    public void addAll(Iterator4 iterator) {
        while (iterator.moveNext()) {
            add(iterator.current());
        }
    }

    public void add(Object element) {
        this._tree = Tree.add(this._tree, new TreeObject(element, this._comparison));
    }

    public void remove(Object element) {
        this._tree = Tree.removeLike(this._tree, new TreeObject(element, this._comparison));
    }

    public Object[] toArray(final Object[] array) {
        Tree.traverse(this._tree, new Visitor4() {
            int f8i = 0;

            public void visit(Object obj) {
                Object[] objArr = array;
                int i = this.f8i;
                this.f8i = i + 1;
                objArr[i] = ((TreeObject) obj).key();
            }
        });
        return array;
    }

    public int size() {
        return Tree.size(this._tree);
    }
}
