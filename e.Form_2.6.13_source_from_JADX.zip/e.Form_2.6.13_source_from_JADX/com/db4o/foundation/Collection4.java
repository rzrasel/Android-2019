package com.db4o.foundation;

import com.db4o.types.Unversioned;

public class Collection4 implements Sequence4, Iterable4, DeepClone, Unversioned {
    public List4 _first;
    public List4 _last;
    public int _size;
    public int _version;

    public Collection4(Object[] elements) {
        addAll(elements);
    }

    public Collection4(Iterable4 other) {
        addAll(other);
    }

    public Collection4(Iterator4 iterator) {
        addAll(iterator);
    }

    public Object singleElement() {
        if (size() == 1) {
            return this._first._element;
        }
        throw new IllegalStateException();
    }

    public final void add(Object element) {
        doAdd(element);
        changed();
    }

    public final void prepend(Object element) {
        doPrepend(element);
        changed();
    }

    private void doPrepend(Object element) {
        if (this._first == null) {
            doAdd(element);
            return;
        }
        this._first = new List4(this._first, element);
        this._size++;
    }

    private void doAdd(Object element) {
        if (this._last == null) {
            this._first = new List4(element);
            this._last = this._first;
        } else {
            this._last._next = new List4(element);
            this._last = this._last._next;
        }
        this._size++;
    }

    public final void addAll(Object[] elements) {
        assertNotNull(elements);
        for (Object add : elements) {
            add(add);
        }
    }

    public final void addAll(Iterable4 other) {
        assertNotNull(other);
        addAll(other.iterator());
    }

    public final void addAll(Iterator4 iterator) {
        assertNotNull(iterator);
        while (iterator.moveNext()) {
            add(iterator.current());
        }
    }

    public final void clear() {
        this._first = null;
        this._last = null;
        this._size = 0;
        changed();
    }

    public final boolean contains(Object element) {
        return find(element) != null;
    }

    public boolean containsAll(Iterator4 iter) {
        assertNotNull(iter);
        while (iter.moveNext()) {
            if (!contains(iter.current())) {
                return false;
            }
        }
        return true;
    }

    public final boolean containsByIdentity(Object element) {
        Iterator4 i = internalIterator();
        while (i.moveNext()) {
            if (i.current() == element) {
                return true;
            }
        }
        return false;
    }

    private List4 find(Object obj) {
        for (List4 current = this._first; current != null; current = current._next) {
            if (current.holds(obj)) {
                return current;
            }
        }
        return null;
    }

    public final Object get(Object element) {
        List4 holder = find(element);
        return holder == null ? null : holder._element;
    }

    public Object deepClone(Object newParent) {
        Collection4 col = new Collection4();
        Iterator4 i = internalIterator();
        while (i.moveNext()) {
            Object element = i.current();
            if (element instanceof DeepClone) {
                col.add(((DeepClone) element).deepClone(newParent));
            } else {
                col.add(element);
            }
        }
        return col;
    }

    public final Object ensure(Object element) {
        List4 list = find(element);
        if (list != null) {
            return list._element;
        }
        add(element);
        return element;
    }

    public final Iterator4 iterator() {
        return this._first == null ? Iterators.EMPTY_ITERATOR : new Collection4Iterator(this, this._first);
    }

    public Object get(int index) {
        if (index < 0) {
            throw new IllegalArgumentException();
        }
        List4 cur = this._first;
        while (index > 0 && cur != null) {
            cur = cur._next;
            index--;
        }
        if (cur != null) {
            return cur._element;
        }
        throw new IllegalArgumentException();
    }

    public void removeAll(Iterable4 iterable) {
        removeAll(iterable.iterator());
    }

    public void removeAll(Iterator4 iterator) {
        while (iterator.moveNext()) {
            remove(iterator.current());
        }
    }

    public Object remove(Object a_object) {
        List4 previous = null;
        for (List4 current = this._first; current != null; current = current._next) {
            if (current.holds(a_object)) {
                this._size--;
                adjustOnRemoval(previous, current);
                changed();
                return current._element;
            }
            previous = current;
        }
        return null;
    }

    public void replace(Object oldObject, Object newObject) {
        List4 list = find(oldObject);
        if (list != null) {
            list._element = newObject;
        }
    }

    private void adjustOnRemoval(List4 previous, List4 removed) {
        if (removed == this._first) {
            this._first = removed._next;
        } else {
            previous._next = removed._next;
        }
        if (removed == this._last) {
            this._last = previous;
        }
    }

    public final int size() {
        return this._size;
    }

    public int indexOf(Object obj) {
        int index = 0;
        for (List4 current = this._first; current != null; current = current._next) {
            if (current.holds(obj)) {
                return index;
            }
            index++;
        }
        return -1;
    }

    public final boolean isEmpty() {
        return this._size == 0;
    }

    public final Object[] toArray(Object[] a_array) {
        int j = 0;
        Iterator4 i = internalIterator();
        while (i.moveNext()) {
            int j2 = j + 1;
            a_array[j] = i.current();
            j = j2;
        }
        return a_array;
    }

    public final Object[] toArray() {
        Object[] array = new Object[this._size];
        toArray(array);
        return array;
    }

    public String toString() {
        return Iterators.toString(internalIterator());
    }

    private void changed() {
        this._version++;
    }

    int version() {
        return this._version;
    }

    private void assertNotNull(Object element) {
        if (element == null) {
            throw new ArgumentNullException();
        }
    }

    private Iterator4 internalIterator() {
        return new Iterator4Impl(this._first);
    }
}
