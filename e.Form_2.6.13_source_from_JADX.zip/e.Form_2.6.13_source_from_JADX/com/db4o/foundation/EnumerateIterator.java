package com.db4o.foundation;

public class EnumerateIterator extends MappingIterator {
    private int _index = 0;

    public static final class Tuple {
        public final int index;
        public final Object value;

        public Tuple(int index_, Object value_) {
            this.index = index_;
            this.value = value_;
        }
    }

    public EnumerateIterator(Iterator4 iterator) {
        super(iterator);
    }

    public boolean moveNext() {
        if (!super.moveNext()) {
            return false;
        }
        this._index++;
        return true;
    }

    protected Object map(Object current) {
        return new Tuple(this._index, current);
    }
}
