package com.db4o.foundation;

public interface ShallowClone {
    Object shallowClone();
}
