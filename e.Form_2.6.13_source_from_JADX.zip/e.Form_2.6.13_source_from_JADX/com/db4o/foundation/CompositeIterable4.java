package com.db4o.foundation;

public class CompositeIterable4 implements Iterable4 {
    private final Iterable4 _iterables;

    public CompositeIterable4(Iterable4 iterables) {
        this._iterables = iterables;
    }

    public Iterator4 iterator() {
        return new CompositeIterator4(this._iterables.iterator()) {
            protected Iterator4 nextIterator(Object current) {
                return ((Iterable4) current).iterator();
            }
        };
    }
}
