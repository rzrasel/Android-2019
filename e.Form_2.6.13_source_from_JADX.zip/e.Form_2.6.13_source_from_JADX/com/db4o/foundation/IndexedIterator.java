package com.db4o.foundation;

public abstract class IndexedIterator implements Iterator4 {
    private final int _length;
    private int _next = -1;

    protected abstract Object get(int i);

    public IndexedIterator(int length) {
        this._length = length;
    }

    public boolean moveNext() {
        if (this._next < lastIndex()) {
            this._next++;
            return true;
        }
        this._next = this._length;
        return false;
    }

    public Object current() {
        return get(this._next);
    }

    public void reset() {
        this._next = -1;
    }

    private int lastIndex() {
        return this._length - 1;
    }
}
