package com.db4o.foundation;

public class BooleanByRef {
    public boolean value;

    public BooleanByRef() {
        this(false);
    }

    public BooleanByRef(boolean value_) {
        this.value = value_;
    }
}
