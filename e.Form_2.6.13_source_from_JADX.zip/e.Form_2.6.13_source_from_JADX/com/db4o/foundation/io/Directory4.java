package com.db4o.foundation.io;

import java.io.File;

public class Directory4 {
    public static void delete(String path, boolean recurse) {
        File f = new File(path);
        if (recurse) {
            delete(f.listFiles());
        }
        File4.translateDeleteFailureToException(f);
    }

    private static void delete(File[] files) {
        for (File f : files) {
            if (f.isDirectory()) {
                delete(f.listFiles());
            }
            File4.translateDeleteFailureToException(f);
        }
    }
}
