package com.db4o.foundation;

public final class BitMap4 {
    private final byte[] _bits;

    public BitMap4(int numBits) {
        this._bits = new byte[byteCount(numBits)];
    }

    public BitMap4(byte[] buffer, int pos, int numBits) {
        this(numBits);
        System.arraycopy(buffer, pos, this._bits, 0, this._bits.length);
    }

    public BitMap4(byte singleByte) {
        this._bits = new byte[]{singleByte};
    }

    public boolean isTrue(int bit) {
        return ((this._bits[arrayOffset(bit)] >>> byteOffset(bit)) & 1) != 0;
    }

    public boolean isFalse(int bit) {
        return !isTrue(bit);
    }

    public int marshalledLength() {
        return this._bits.length;
    }

    public void setFalse(int bit) {
        byte[] bArr = this._bits;
        int arrayOffset = arrayOffset(bit);
        bArr[arrayOffset] = (byte) (bArr[arrayOffset] & ((byte) (bitMask(bit) ^ -1)));
    }

    public void set(int bit, boolean val) {
        if (val) {
            setTrue(bit);
        } else {
            setFalse(bit);
        }
    }

    public void setTrue(int bit) {
        byte[] bArr = this._bits;
        int arrayOffset = arrayOffset(bit);
        bArr[arrayOffset] = (byte) (bArr[arrayOffset] | bitMask(bit));
    }

    public void writeTo(byte[] bytes, int pos) {
        System.arraycopy(this._bits, 0, bytes, pos, this._bits.length);
    }

    private byte byteOffset(int bit) {
        return (byte) (bit % 8);
    }

    private int arrayOffset(int bit) {
        return bit / 8;
    }

    private byte bitMask(int bit) {
        return (byte) (1 << byteOffset(bit));
    }

    private int byteCount(int numBits) {
        return (numBits + 7) / 8;
    }

    public byte getByte(int index) {
        return this._bits[index];
    }

    public byte[] bytes() {
        return this._bits;
    }
}
