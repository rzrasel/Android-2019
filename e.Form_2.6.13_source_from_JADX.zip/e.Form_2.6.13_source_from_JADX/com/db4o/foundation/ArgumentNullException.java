package com.db4o.foundation;

public final class ArgumentNullException extends IllegalArgumentException {
    public ArgumentNullException(String name) {
        super(name);
    }
}
