package com.db4o;

public interface Internal4 {
}
