package com.db4o;

public class MetaClass implements Internal4 {
    public MetaField[] fields;
    public String name;
}
