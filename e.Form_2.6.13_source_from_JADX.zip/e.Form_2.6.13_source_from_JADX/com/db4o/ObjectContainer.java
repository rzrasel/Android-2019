package com.db4o;

import com.db4o.ext.DatabaseClosedException;
import com.db4o.ext.DatabaseReadOnlyException;
import com.db4o.ext.Db4oIOException;
import com.db4o.ext.ExtObjectContainer;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import com.db4o.query.QueryComparator;
import java.util.Comparator;

public interface ObjectContainer {
    void activate(Object obj, int i) throws Db4oIOException, DatabaseClosedException;

    boolean close() throws Db4oIOException;

    void commit() throws Db4oIOException, DatabaseClosedException, DatabaseReadOnlyException;

    void deactivate(Object obj, int i) throws DatabaseClosedException;

    void delete(Object obj) throws Db4oIOException, DatabaseClosedException, DatabaseReadOnlyException;

    ExtObjectContainer ext();

    <T> ObjectSet<T> get(Object obj) throws Db4oIOException, DatabaseClosedException;

    <TargetType> ObjectSet<TargetType> query(Predicate<TargetType> predicate) throws Db4oIOException, DatabaseClosedException;

    <TargetType> ObjectSet<TargetType> query(Predicate<TargetType> predicate, QueryComparator<TargetType> queryComparator) throws Db4oIOException, DatabaseClosedException;

    <TargetType> ObjectSet<TargetType> query(Predicate<TargetType> predicate, Comparator<TargetType> comparator) throws Db4oIOException, DatabaseClosedException;

    <TargetType> ObjectSet<TargetType> query(Class<TargetType> cls) throws Db4oIOException, DatabaseClosedException;

    Query query() throws DatabaseClosedException;

    <T> ObjectSet<T> queryByExample(Object obj) throws Db4oIOException, DatabaseClosedException;

    void rollback() throws Db4oIOException, DatabaseClosedException, DatabaseReadOnlyException;

    void set(Object obj) throws DatabaseClosedException, DatabaseReadOnlyException;

    void store(Object obj) throws DatabaseClosedException, DatabaseReadOnlyException;
}
