package com.edmodo.cropper;

import net.ion.eform.service.R;

public final class C0430R {

    public static final class attr {
        public static final int aspectRatioX = 2130772011;
        public static final int aspectRatioY = 2130772012;
        public static final int fixAspectRatio = 2130772010;
        public static final int guidelines = 2130772009;
        public static final int imageResource = 2130772013;
    }

    public static final class color {
        public static final int black_translucent = 2131623998;
    }

    public static final class id {
        public static final int CropOverlayView = 2131689770;
        public static final int ImageView_image = 2131689769;
        public static final int off = 2131689504;
        public static final int on = 2131689505;
        public static final int onTouch = 2131689506;
    }

    public static final class layout {
        public static final int crop_image_view = 2130968617;
    }

    public static final class string {
        public static final int app_name = 2131231284;
    }

    public static final class styleable {
        public static final int[] CropImageView = new int[]{R.attr.guidelines, R.attr.fixAspectRatio, R.attr.aspectRatioX, R.attr.aspectRatioY, R.attr.imageResource};
        public static final int CropImageView_aspectRatioX = 2;
        public static final int CropImageView_aspectRatioY = 3;
        public static final int CropImageView_fixAspectRatio = 1;
        public static final int CropImageView_guidelines = 0;
        public static final int CropImageView_imageResource = 4;
    }
}
