package com.jeremyfeinstein.slidingmenu.lib;

import net.ion.eform.service.R;

public final class C0522R {

    public static final class attr {
        public static final int behindOffset = 2130772098;
        public static final int behindScrollScale = 2130772100;
        public static final int behindWidth = 2130772099;
        public static final int fadeDegree = 2130772106;
        public static final int fadeEnabled = 2130772105;
        public static final int mode = 2130772095;
        public static final int selectorDrawable = 2130772108;
        public static final int selectorEnabled = 2130772107;
        public static final int shadowDrawable = 2130772103;
        public static final int shadowWidth = 2130772104;
        public static final int touchModeAbove = 2130772101;
        public static final int touchModeBehind = 2130772102;
        public static final int viewAbove = 2130772096;
        public static final int viewBehind = 2130772097;
    }

    public static final class id {
        public static final int fullscreen = 2131689531;
        public static final int left = 2131689529;
        public static final int margin = 2131689532;
        public static final int none = 2131689499;
        public static final int right = 2131689530;
        public static final int selected_view = 2131689488;
        public static final int slidingmenumain = 2131690141;
    }

    public static final class layout {
        public static final int slidingmenumain = 2130968720;
    }

    public static final class styleable {
        public static final int[] SlidingMenu = new int[]{R.attr.mode, R.attr.viewAbove, R.attr.viewBehind, R.attr.behindOffset, R.attr.behindWidth, R.attr.behindScrollScale, R.attr.touchModeAbove, R.attr.touchModeBehind, R.attr.shadowDrawable, R.attr.shadowWidth, R.attr.fadeEnabled, R.attr.fadeDegree, R.attr.selectorEnabled, R.attr.selectorDrawable};
        public static final int SlidingMenu_behindOffset = 3;
        public static final int SlidingMenu_behindScrollScale = 5;
        public static final int SlidingMenu_behindWidth = 4;
        public static final int SlidingMenu_fadeDegree = 11;
        public static final int SlidingMenu_fadeEnabled = 10;
        public static final int SlidingMenu_mode = 0;
        public static final int SlidingMenu_selectorDrawable = 13;
        public static final int SlidingMenu_selectorEnabled = 12;
        public static final int SlidingMenu_shadowDrawable = 8;
        public static final int SlidingMenu_shadowWidth = 9;
        public static final int SlidingMenu_touchModeAbove = 6;
        public static final int SlidingMenu_touchModeBehind = 7;
        public static final int SlidingMenu_viewAbove = 1;
        public static final int SlidingMenu_viewBehind = 2;
    }
}
