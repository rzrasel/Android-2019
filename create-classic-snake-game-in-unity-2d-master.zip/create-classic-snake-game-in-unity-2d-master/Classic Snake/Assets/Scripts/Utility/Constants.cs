﻿using UnityEngine;
using System.Collections;

public static class Constants  {

	public static float SPEED = 15f;

	public const float SNAKE_PART_DISTANCE = .95f, SNAKE_TAIL_DISTANCE = .535f;

	//public static bool isIpad;
}
