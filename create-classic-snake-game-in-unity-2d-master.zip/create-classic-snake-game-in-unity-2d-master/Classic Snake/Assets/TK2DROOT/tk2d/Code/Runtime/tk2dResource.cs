using UnityEngine;
using System.Collections;

public class tk2dResource : ScriptableObject
{
	public UnityEngine.Object objectReference = null;
}
