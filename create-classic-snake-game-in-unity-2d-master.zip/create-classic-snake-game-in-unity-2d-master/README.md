# create-classic-snake-game-in-unity-2d

Main objective of this blog is to give an idea about how to Create Classic Snake Game in Unity 2D.

You can find complete tutorial on how to use this code repo here : [Create Classic Snake Game in Unity 2D](http://www.theappguruz.com/blog/create-classic-snake-game-in-unity-2d)

This Tutorial has been presented by The App Guruz - One of the best [Game Development Company in India](http://www.theappguruz.com/mobile-application-development/)
